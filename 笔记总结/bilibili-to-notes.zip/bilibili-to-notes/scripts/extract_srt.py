#!/usr/bin/env python3
"""Extract pure text from SRT subtitle file, removing timestamps and line numbers."""

import re
import sys


def extract_text(srt_path: str, output_path: str) -> str:
    with open(srt_path, "r", encoding="utf-8") as f:
        content = f.read()

    lines = content.split("\n")
    text_lines = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if re.match(r"^\d+$", line):
            continue
        if re.match(r"^\d{2}:\d{2}:\d{2},\d{3}", line):
            continue
        text_lines.append(line)

    full_text = "".join(text_lines)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(full_text)

    return full_text


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python extract_srt.py <input.srt> <output.txt>")
        sys.exit(1)

    text = extract_text(sys.argv[1], sys.argv[2])
    print(f"Extracted {len(text)} characters → {sys.argv[2]}")
