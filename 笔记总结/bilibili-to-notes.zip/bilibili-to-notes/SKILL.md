---
name: bilibili-to-notes
description: "This skill should be used when the user wants to convert a Bilibili video into a structured Markdown learning note. It handles the full pipeline: download Bilibili video, speech-to-text via VideoCaptioner, extract pure text from SRT, generate structured Markdown notes. Triggers include: '把这个视频转换一下', 'B站视频转笔记', 'video to notes', '视频转录', or any request involving Bilibili URL and video-to-text conversion."
agent_created: true
---

# Bilibili Video to Learning Notes

## Overview

Convert Bilibili tutorial videos into structured Markdown learning notes. The pipeline uses
[VideoCaptioner](https://github.com/WEIFENG2333/VideoCaptioner) (卡卡字幕助手) for download and
ASR, then leverages built-in LLM capabilities to organize raw transcripts into well-structured
study notes with knowledge points, code examples, and summary tables.

## Prerequisites

Ensure these are installed before starting:

- **Python** >= 3.10, < 3.13
- **VideoCaptioner**: `pip install videocaptioner`
- **FFmpeg**: Required for audio extraction and the bijian ASR engine
  - On Windows, install via `winget install Gyan.FFmpeg.Essentials`
  - The binary may need to be added to PATH manually. Typical install path:
    `%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg.Essentials_*\ffmpeg-*-essentials_build\bin\`
  - Verify: `ffmpeg -version`

## Workflow

### Step 1: Download the Bilibili Video

```bash
cd <workspace>
videocaptioner download "<B站视频URL>" -o ./video_output
```

- Supports paging: append `?p=22` to the URL for specific episodes
- Output goes to `./video_output/` directory
- If FFmpeg is installed, video+audio are merged into a single `.mp4`
- Without FFmpeg, video and audio are separate files (use the `.m4a` audio for ASR)

### Step 2: Transcribe with ASR

```bash
# Ensure FFmpeg is in PATH first (Windows winget path):
export PATH="$LOCALAPPDATA/Microsoft/WinGet/Packages/Gyan.FFmpeg.Essentials_*/ffmpeg-*-essentials_build/bin:$PATH"

videocaptioner transcribe "<video-or-audio-file>" --asr bijian --language zh -o ./video_output
```

- `--asr bijian`: Free, no-config ASR engine (Chinese/English)
- `--language zh`: Specify Chinese as source language
- `--no-synthesize`: (Not needed for `transcribe`) Only generate subtitles
- Output: `.srt` subtitle file in the output directory

### Step 3: Extract Pure Text from SRT

Run the bundled extraction script:

```bash
python scripts/extract_srt.py <input.srt> <output.txt>
```

Or inline (if script path differs):

```python
import re
with open('subtitle.srt', 'r', encoding='utf-8') as f:
    content = f.read()
text = ''.join(l for l in content.split('\n') if (s:=l.strip()) and not re.match(r'^\d+$|^\d{2}:\d{2}:\d{2},\d{3}', s))
with open('transcript.txt', 'w', encoding='utf-8') as f:
    f.write(text)
```

### Step 4: Read the Full Transcript

Read the extracted transcript file to understand the full content. If the file is very long
(>10k characters), read in segments to get complete coverage.

### Step 5: Generate Structured Learning Notes

After reading the transcript, generate a comprehensive Markdown learning note. The note must be
saved to a `.md` file in the same output directory.

**Output quality standards:**

1. **Title**: Extract the video title and topic. Use `# Title` format with subtitle reference.
2. **Section structure**: Organize by logical topics (hardware setup → theory → code → practice).
3. **Code blocks**: Include complete, runnable code snippets with Chinese comments.
4. **Comparison tables**: Use tables to contrast modes, parameters, or approaches.
5. **Summary diagrams**: Include ASCII or mermaid diagrams for architecture/frameworks.
6. **Cheat sheets**: Provide quick-reference tables for register names, pin assignments, etc.
7. **Key insights**: Highlight common pitfalls, non-obvious behavior, and best practices.
8. **Chinese**: All explanatory text in Chinese; code identifiers in English.

**Note content checklist:**

- [ ] Video metadata (source, episode, chip model)
- [ ] Hardware wiring diagrams (pin tables)
- [ ] Configuration steps (numbered, with function names)
- [ ] Complete code examples (init + main)
- [ ] Parameter comparison tables
- [ ] Common pitfalls and workarounds
- [ ] Knowledge summary diagram

### Step 6: Clean Up

Delete the downloaded `.mp4` video file to save disk space:

```bash
rm video_output/*.mp4
```

Keep the `.srt` subtitle, `.txt` transcript, and `.md` notes.

### Step 7: Deliver

Deliver the following files to the user (in priority order):
1. The `.md` learning note (most important)
2. The `.srt` subtitle file
3. The `.txt` transcript (optional, if requested)

Use `deliver_attachments` to send the files.

## Tips

- The bijian ASR engine always splits long audio into chunks for parallel processing. This is
  normal and handled automatically.
- Bilibili 1080P/720P requires premium membership cookies. The free 360P quality is sufficient
  for audio-based ASR since audio quality is independent of video resolution.
- If `videocaptioner process` fails with "LLM API key not configured", use `transcribe` instead
  — it does pure ASR without LLM-based subtitle optimization.
- The generated note should be directly usable as study material. Include enough detail that a
  reader who didn't watch the video can understand the concepts.

## Known Limitations

- bijian ASR only supports Chinese and English
- Free Bilibili download quality is limited without cookies
- Long videos (>30 minutes) may take several minutes for ASR due to chunked processing
